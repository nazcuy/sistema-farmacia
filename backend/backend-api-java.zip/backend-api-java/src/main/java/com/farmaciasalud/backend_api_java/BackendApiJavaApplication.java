package com.farmaciasalud.backend_api_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendApiJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendApiJavaApplication.class, args);
	}

}
